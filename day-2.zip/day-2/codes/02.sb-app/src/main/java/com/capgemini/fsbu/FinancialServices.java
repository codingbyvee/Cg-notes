package com.capgemini.fsbu;

import org.springframework.stereotype.Component;

@Component
public class FinancialServices {

	public FinancialServices() {
		System.out.println("FinancialServices :: Constructor");
	}

}
