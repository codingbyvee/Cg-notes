package com.capgemini.boot.beans.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class VehicleController {

	public VehicleController() {
		System.out.println("VehicleController :: Constructor");
	}

}
