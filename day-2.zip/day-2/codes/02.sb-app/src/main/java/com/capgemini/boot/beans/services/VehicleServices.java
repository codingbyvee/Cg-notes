package com.capgemini.boot.beans.services;

import org.springframework.stereotype.Service;

@Service
public class VehicleServices {

	public VehicleServices() {
		System.out.println("VehicleServices :: Constructor");
	}

}
