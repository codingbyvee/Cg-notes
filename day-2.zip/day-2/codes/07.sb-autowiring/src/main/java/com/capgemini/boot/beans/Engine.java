package com.capgemini.boot.beans;

public interface Engine {
	public boolean startEngine(); 
}
