package com.capgemini.boot.security.models;

public record Product(Integer productId, String productName) {}
