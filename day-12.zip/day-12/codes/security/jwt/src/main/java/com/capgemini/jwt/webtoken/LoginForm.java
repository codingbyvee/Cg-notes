package com.capgemini.jwt.webtoken;

public record LoginForm (String username, String password) {
}
