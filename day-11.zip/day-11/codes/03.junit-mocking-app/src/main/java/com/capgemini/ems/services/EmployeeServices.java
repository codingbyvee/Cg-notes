package com.capgemini.ems.services;

public interface EmployeeServices {
	public String getEmployeeNameById(int eid);
}
