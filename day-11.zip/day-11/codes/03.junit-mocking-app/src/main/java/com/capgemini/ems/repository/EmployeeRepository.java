package com.capgemini.ems.repository;

public interface EmployeeRepository {
	
	public String findEmployeeNameById(int eid);
}
