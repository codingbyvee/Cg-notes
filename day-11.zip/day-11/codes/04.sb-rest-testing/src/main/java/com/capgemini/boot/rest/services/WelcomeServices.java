package com.capgemini.boot.rest.services;

public interface WelcomeServices {
	public String generateWelcomeMesssage();
}
