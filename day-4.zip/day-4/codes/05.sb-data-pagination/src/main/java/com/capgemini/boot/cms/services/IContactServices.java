package com.capgemini.boot.cms.services;

public interface IContactServices {
	public void getContactsInPages();
}
