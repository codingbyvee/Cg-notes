package com.capgemini.accounts.service;

import com.capgemini.accounts.dto.CustomerDetailsDto;

public interface ICustomerService {
	
	CustomerDetailsDto fetchCustomerDetails(String mobileNumber);

}
