package com.capgemini.boot.rest.services;

import org.springframework.stereotype.Component;

public interface WelcomeService {
	public String generateWelcomeMessage();
}
