package com.capgemini.students.model;

import lombok.Data;

@Data
public class SubjectRequest {
	private String subjectName;

	private Double marksObtained;
}
