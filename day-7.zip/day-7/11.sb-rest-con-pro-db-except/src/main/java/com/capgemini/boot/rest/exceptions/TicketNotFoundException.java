package com.capgemini.boot.rest.exceptions;

public class TicketNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public TicketNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TicketNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
