package com.capgemini.constants;

public class AppContants {
 public static final String INDEX_VIEW = "index";
 
 public static final String SAVE_SUCCESS = "saveSuccess";
 
 public static final String UPDATE_SUCCESS = "updateSuccess";
 
 public static final String SAVE_FAILED = "saveFail";
 
 public static final String SUCCESS_MSG = "succMsg";
 
 public static final String ERROR_MSG = "errMsg";
}
